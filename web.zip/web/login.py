#!/usr/bin/python3

IST_ID = 'ist1103783'
host = 'db.tecnico.ulisboa.pt'
port = 5432
password = 'bnwc4559'
db_name = IST_ID

credentials = 'host={} port={} user={} password={} dbname={}'.format(host, port, IST_ID, password, db_name)
